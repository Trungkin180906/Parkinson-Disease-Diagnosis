DATASET PLACEHOLDER
Download HandPD from the official source listed in scripts/download_links.txt.
Place the extracted images and CSVs in this folder.
The project archive does not redistribute the dataset itself.
