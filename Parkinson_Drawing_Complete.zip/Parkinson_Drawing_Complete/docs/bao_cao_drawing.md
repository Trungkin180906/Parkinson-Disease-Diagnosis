# BÁO CÁO – ỨNG DỤNG AI PHÂN TÍCH HÌNH VẼ HỖ TRỢ SÀNG LỌC PARKINSON

## 1. Giới thiệu

Hệ thống Parkinson-Disease-Diagnosis được xây dựng theo hướng AI đa mô hình. Ở giai đoạn sàng lọc ban đầu, mô-đun Drawing Analysis tiếp nhận hình vẽ của người dùng, đặc biệt là bài kiểm tra hình xoắn ốc (Spiral Drawing Test), sau đó sử dụng Computer Vision và Deep Learning để ước lượng mức độ tương đồng với nhóm dữ liệu Parkinson trong tập huấn luyện.

Mục tiêu của mô-đun là tạo ra một chỉ số hỗ trợ sàng lọc gọi là **Drawing Risk Score**, sau đó kết hợp với các mô hình khác như Gait Analysis để tạo Overall Risk Score.

## 2. Dataset HandPD

HandPD là bộ dữ liệu công khai do nhóm nghiên cứu tại Botucatu Medical School, São Paulo State University, Brazil xây dựng. Bộ dữ liệu gồm 92 cá nhân: 18 người khỏe mạnh và 74 bệnh nhân Parkinson. Mỗi bài kiểm tra có bốn hình xoắn ốc và bốn hình meander; dữ liệu được cắt thành ảnh JPG. Toàn bộ HandPD có 736 ảnh, gồm 368 spiral và 368 meander.

Nhãn trong CSV:
- CLASS_TYPE = 1: control
- CLASS_TYPE = 2: patient

CSV còn có ID_PATIENT, ID_EXAM, IMAGE_NAME, giới tính, thuận tay, tuổi và nhiều đặc trưng được công bố cùng dataset như RMS, sai khác giữa template và handwritten trace, độ lệch chuẩn, MRT và các biến mô tả biến thiên nét vẽ.

Nguồn: trang chính thức HandPD và bài báo CMPB-2016.

## 3. Vấn đề dữ liệu

HandPD mất cân bằng lớp: số mẫu bệnh nhân lớn hơn nhiều so với nhóm control. Ngoài ra, một bệnh nhân có thể có nhiều ảnh/exam. Vì vậy nếu chia train/test theo từng ảnh một cách ngẫu nhiên, ảnh của cùng một bệnh nhân có thể xuất hiện ở nhiều tập, gây data leakage.

Giải pháp của project:
- Split theo ID_PATIENT.
- Train/Validation/Test xấp xỉ 70/15/15.
- Dùng class-weighted Cross Entropy.
- Augmentation chỉ áp dụng cho training.

## 4. Tiền xử lý

Pipeline:
1. Đọc CSV.
2. Ghép IMAGE_NAME với thư mục ảnh.
3. Loại ảnh bị thiếu.
4. Chuyển ảnh sang RGB.
5. Resize 224×224.
6. Training augmentation: rotation nhỏ và affine nhẹ.
7. Chuẩn hóa theo mean/std ImageNet.
8. Chia dữ liệu theo patient.

## 5. Mô hình ResNet-18

Project sử dụng Transfer Learning với ResNet-18 pretrained ImageNet.

Kiến trúc:
Input image → ResNet-18 backbone → Fully Connected 2 classes → Softmax.

Hai lớp:
- Control
- Parkinson

Đầu ra quan trọng nhất là P(Parkinson).

## 6. Huấn luyện

Loss:
CrossEntropyLoss có class weights để giảm ảnh hưởng của mất cân bằng lớp.

Optimizer:
AdamW, learning rate mặc định 1e-4, weight decay 1e-4.

Scheduler:
ReduceLROnPlateau theo validation ROC-AUC.

Early stopping:
Dừng nếu validation metric không cải thiện trong 5 epoch.

## 7. Đánh giá

Các chỉ số:
- Accuracy
- Precision
- Recall/Sensitivity
- Specificity
- F1-score
- ROC-AUC
- Confusion Matrix

Không nên chỉ báo cáo Accuracy vì dataset mất cân bằng.

## 8. Drawing Risk Score

Định nghĩa trong ứng dụng:

Drawing Risk Score = P(Parkinson) × 100

Ví dụ P(Parkinson)=0.82 thì Drawing Risk Score=82/100.

Mức hiển thị:
- 0–30: Thấp
- 31–60: Trung bình
- 61–80: Cao
- 81–100: Rất cao

Nếu score ≥70, hệ thống hiển thị khuyến nghị người dùng nên trao đổi với nhân viên y tế để được đánh giá thêm.

**Lưu ý:** Score này là đầu ra của mô hình sàng lọc, không phải xác suất mắc bệnh thực tế và không phải chẩn đoán y khoa.

## 9. Theo dõi qua nhiều lần kiểm tra

Mỗi lần người dùng thực hiện bài kiểm tra, hệ thống lưu:
- thời gian kiểm tra;
- loại hình vẽ;
- Drawing Risk Score;
- model version.

Có thể biểu diễn thành biểu đồ theo thời gian:

Lần 1 → 54
Lần 2 → 61
Lần 3 → 67
Lần 4 → 72

Mục đích là phát hiện xu hướng thay đổi của điểm mô hình, thay vì kết luận mức độ bệnh từ một lần đo.

HandPD bản gốc không phải dataset longitudinal severity và không cung cấp nhãn UPDRS để huấn luyện trực tiếp mức độ bệnh. Do đó, chức năng này nên được mô tả là **theo dõi xu hướng điểm nguy cơ từ hình vẽ**.

## 10. Kết hợp với hệ thống AI đa mô hình

Drawing Risk Score có thể kết hợp với Gait Risk Score:

Overall Risk = w1 × Drawing Risk + w2 × Gait Risk

Ví dụ nếu hai trọng số bằng nhau:
Overall Risk = (Drawing Risk + Gait Risk)/2.

Ví dụ:
Drawing = 82
Gait = 76
Overall = 79

Nếu Overall ≥70, hệ thống khuyến nghị đánh giá y tế.

Voice Analysis là mô-đun theo dõi sau khi người dùng đã được bác sĩ xác nhận Parkinson, có thể theo dõi các đặc trưng như pitch, jitter, shimmer và HNR theo thời gian.

## 11. Giao diện đề xuất

Màn hình Drawing Test:
- Upload/Camera hình spiral.
- Preview hình.
- Nút Analyze.
- Loading.
- Drawing Risk Score.
- Risk level.
- Khuyến nghị.
- Lịch sử các lần kiểm tra.

Màn hình theo dõi:
- Biểu đồ Drawing Risk Score theo ngày.
- So sánh với Gait Risk Score.
- Overall Risk.
- Cảnh báo khi xu hướng tăng.

## 12. Hạn chế

1. HandPD có mất cân bằng lớp.
2. Số lượng người tham gia không lớn.
3. Dữ liệu được thu trong môi trường nghiên cứu, không đại diện toàn bộ dân số.
4. Mô hình ảnh không trực tiếp đo tốc độ vẽ vì ảnh tĩnh không chứa đầy đủ thông tin thời gian.
5. Không được diễn giải Drawing Risk Score thành chẩn đoán.
6. Không thể dùng HandPD để tuyên bố mô hình đo trực tiếp severity/UPDRS.

Nếu muốn phân tích động học của nét vẽ, NewHandPD phù hợp hơn vì có hình ảnh và tín hiệu động thu bằng smart pen.

## 13. Kết luận

Mô-đun Drawing Analysis cung cấp một pipeline hoàn chỉnh từ dữ liệu HandPD đến mô hình ResNet-18 và Drawing Risk Score. Thiết kế split theo bệnh nhân giúp giảm nguy cơ data leakage, class-weighted loss xử lý mất cân bằng, còn ROC-AUC, sensitivity, specificity và F1 giúp đánh giá mô hình toàn diện hơn Accuracy.

Trong hệ thống tổng thể, Drawing Analysis là một nguồn bằng chứng độc lập để kết hợp với Gait Analysis. Kết quả cuối cùng cần được xem như công cụ hỗ trợ sàng lọc và theo dõi, không thay thế chẩn đoán của bác sĩ.

## 14. Tài liệu tham khảo

[1] HandPD Dataset, São Paulo State University:
https://wwwp.fc.unesp.br/~papa/pub/datasets/Handpd/

[2] C. R. Pereira et al., "A new computer vision-based approach to aid the diagnosis of Parkinson's disease", Computer Methods and Programs in Biomedicine, 136, 79–88, 2016.
DOI: 10.1016/j.cmpb.2016.08.005
