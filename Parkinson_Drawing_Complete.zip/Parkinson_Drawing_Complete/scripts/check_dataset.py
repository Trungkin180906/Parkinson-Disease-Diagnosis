from pathlib import Path
import pandas as pd

ROOT=Path("data/drawing")
for kind in ["spiral","meander"]:
    csv=ROOT/f"{'Spiral' if kind=='spiral' else 'Meander'}_HandPD.csv"
    img=ROOT/kind
    print(f"\n[{kind.upper()}]")
    if not csv.exists():
        print("CSV MISSING:",csv)
        continue
    df=pd.read_csv(csv)
    print("CSV rows:",len(df))
    print("Patients:",df.ID_PATIENT.nunique())
    print("Labels:",df.CLASS_TYPE.value_counts().to_dict())
    exists=df.IMAGE_NAME.astype(str).map(lambda x:(img/x).exists())
    print("Images found:",int(exists.sum()),"/",len(df))
    print("Missing images:",int((~exists).sum()))
