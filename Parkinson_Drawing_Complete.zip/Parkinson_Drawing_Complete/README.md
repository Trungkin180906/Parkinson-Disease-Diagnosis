# Parkinson Disease – Drawing Analysis Model

Mô-đun phân tích hình vẽ cho hệ thống AI đa mô hình sàng lọc Parkinson.

## 1. Dataset

Nguồn chính thức HandPD:
https://wwwp.fc.unesp.br/~papa/pub/datasets/Handpd/

HandPD gồm 92 người: 18 healthy controls và 74 Parkinson's patients; 736 ảnh, gồm 368 spiral và 368 meander. CSV có `ID_PATIENT`, `CLASS_TYPE` (1=control, 2=patient), `IMAGE_NAME` và các đặc trưng hình học/tremor.

**Không commit dữ liệu gốc vào GitHub.** Hãy tải dataset từ nguồn chính thức và đặt:
- `data/drawing/spiral/`
- `data/drawing/meander/`
- `data/drawing/Spiral_HandPD.csv`
- `data/drawing/Meander_HandPD.csv`

## 2. Cài đặt

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
pip install -r requirements.txt
```

## 3. Chuẩn bị dữ liệu

```bash
python scripts/check_dataset.py
```

Script kiểm tra số ảnh, CSV, label và trùng patient.

## 4. Huấn luyện Spiral model

```bash
python -m ai.drawing.train --csv data/drawing/Spiral_HandPD.csv --image-dir data/drawing/spiral --output results/drawing_spiral
```

## 5. Huấn luyện Meander model

```bash
python -m ai.drawing.train --csv data/drawing/Meander_HandPD.csv --image-dir data/drawing/meander --output results/drawing_meander
```

## 6. Dự đoán một ảnh

```bash
python -m ai.drawing.predict --checkpoint results/drawing_spiral/best_model.pt --image path/to/image.jpg
```

Output:
- probability Parkinson
- Drawing Risk Score 0–100
- risk level

## 7. Đánh giá

```bash
python -m ai.drawing.evaluate --checkpoint results/drawing_spiral/best_model.pt --split results/drawing_spiral/test.csv
```

## 8. Nguyên tắc chống data leakage

Split theo `ID_PATIENT`, không split ngẫu nhiên theo từng ảnh. Vì một bệnh nhân có thể có nhiều ảnh/exam; nếu cùng một bệnh nhân xuất hiện ở train và test thì điểm số có thể bị thổi phồng.

## 9. Ý nghĩa y khoa

Model là công cụ hỗ trợ sàng lọc, không phải công cụ chẩn đoán. `Drawing Risk Score` là điểm nguy cơ do mô hình tạo ra, không phải xác suất bệnh thực tế.

HandPD là dữ liệu phân loại control/patient và không cung cấp nhãn severity/UPDRS cho mô hình ảnh này. Vì vậy báo cáo nên gọi chức năng theo dõi là **theo dõi xu hướng Drawing Risk Score qua các lần kiểm tra**, không tuyên bố mô hình đo trực tiếp mức độ bệnh.

## 10. Citation

Pereira et al., "A new computer vision-based approach to aid the diagnosis of Parkinson's disease", Computer Methods and Programs in Biomedicine, 136, 79–88, 2016.
DOI: 10.1016/j.cmpb.2016.08.005
