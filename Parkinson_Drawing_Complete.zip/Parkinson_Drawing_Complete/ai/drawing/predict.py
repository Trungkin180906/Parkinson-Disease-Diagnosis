import argparse, json
from pathlib import Path
import torch
from torchvision import transforms, models
from PIL import Image
from torch import nn

def load_model(checkpoint, device):
    ckpt=torch.load(checkpoint,map_location=device)
    model=models.resnet18(weights=None)
    model.fc=nn.Linear(model.fc.in_features,2)
    model.load_state_dict(ckpt["model_state"])
    model.eval().to(device)
    return model

def risk_level(score):
    if score <= 30: return "Thấp"
    if score <= 60: return "Trung bình"
    if score <= 80: return "Cao"
    return "Rất cao"

def predict(checkpoint,image):
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model=load_model(checkpoint,device)
    tf=transforms.Compose([
        transforms.Resize((224,224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
    ])
    x=tf(Image.open(image).convert("RGB")).unsqueeze(0).to(device)
    with torch.no_grad():
        p=torch.softmax(model(x),1)[0,1].item()
    score=round(p*100,2)
    return {"parkinson_probability":round(p,4),"drawing_risk_score":score,
            "risk_level":risk_level(score),
            "recommendation":"Nên trao đổi với nhân viên y tế để được đánh giá thêm." if score>=70 else "Tiếp tục theo dõi; không dùng điểm này như chẩn đoán."}

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--checkpoint",required=True); ap.add_argument("--image",required=True)
    args=ap.parse_args()
    print(json.dumps(predict(args.checkpoint,args.image),ensure_ascii=False,indent=2))
