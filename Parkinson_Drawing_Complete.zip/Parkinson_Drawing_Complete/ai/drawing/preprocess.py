from pathlib import Path
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

REQUIRED = {"IMAGE_NAME", "ID_PATIENT", "CLASS_TYPE"}

def load_metadata(csv_path, image_dir):
    csv_path = Path(csv_path)
    image_dir = Path(image_dir)
    df = pd.read_csv(csv_path)
    missing = REQUIRED - set(df.columns)
    if missing:
        raise ValueError(f"CSV thiếu cột: {sorted(missing)}")

    df["image_path"] = df["IMAGE_NAME"].astype(str).apply(lambda x: str(image_dir / x))
    df["label"] = (df["CLASS_TYPE"].astype(int) == 2).astype(int)
    df["exists"] = df["image_path"].apply(lambda x: Path(x).exists())
    df = df[df["exists"]].copy()

    if df.empty:
        raise FileNotFoundError("Không tìm thấy ảnh. Kiểm tra image-dir và IMAGE_NAME.")
    return df

def split_by_patient(df, test_size=0.15, val_size=0.15, random_state=42):
    # 70/15/15 patient-wise split
    gss1 = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=random_state)
    trainval_idx, test_idx = next(gss1.split(df, y=df["label"], groups=df["ID_PATIENT"]))
    trainval = df.iloc[trainval_idx].reset_index(drop=True)
    test = df.iloc[test_idx].reset_index(drop=True)

    relative_val = val_size / (1.0 - test_size)
    gss2 = GroupShuffleSplit(n_splits=1, test_size=relative_val, random_state=random_state + 1)
    train_idx, val_idx = next(gss2.split(trainval, y=trainval["label"], groups=trainval["ID_PATIENT"]))
    train = trainval.iloc[train_idx].reset_index(drop=True)
    val = trainval.iloc[val_idx].reset_index(drop=True)
    return train, val, test

def save_splits(train, val, test, out_dir):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    train.to_csv(out / "train.csv", index=False)
    val.to_csv(out / "val.csv", index=False)
    test.to_csv(out / "test.csv", index=False)
