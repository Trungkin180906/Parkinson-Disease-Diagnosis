import argparse, json
from pathlib import Path
import pandas as pd, torch
from torch.utils.data import DataLoader
from .train import DrawingDataset, make_model, evaluate

ap=argparse.ArgumentParser()
ap.add_argument("--checkpoint",required=True)
ap.add_argument("--split",required=True)
ap.add_argument("--batch-size",type=int,default=16)
args=ap.parse_args()

device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
df=pd.read_csv(args.split)
loader=DataLoader(DrawingDataset(df),args.batch_size,shuffle=False)
model=make_model().to(device)
ckpt=torch.load(args.checkpoint,map_location=device)
model.load_state_dict(ckpt["model_state"])
print(json.dumps(evaluate(model,loader,device),ensure_ascii=False,indent=2))
