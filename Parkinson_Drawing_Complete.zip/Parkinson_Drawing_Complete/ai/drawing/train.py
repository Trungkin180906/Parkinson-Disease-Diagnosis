import argparse, json, random
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from .preprocess import load_metadata, split_by_patient, save_splits

def seed_everything(seed=42):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

class DrawingDataset(Dataset):
    def __init__(self, df, train=False):
        self.df = df.reset_index(drop=True)
        self.tf = transforms.Compose([
            transforms.Resize((224,224)),
            transforms.RandomRotation(8),
            transforms.RandomAffine(degrees=0, translate=(0.03,0.03), scale=(0.95,1.05)) if train else transforms.Lambda(lambda x: x),
            transforms.ToTensor(),
            transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
        ])
    def __len__(self): return len(self.df)
    def __getitem__(self, i):
        r = self.df.iloc[i]
        img = Image.open(r.image_path).convert("RGB")
        return self.tf(img), int(r.label)

def make_model():
    weights = models.ResNet18_Weights.DEFAULT
    model = models.resnet18(weights=weights)
    model.fc = nn.Linear(model.fc.in_features, 2)
    return model

def metrics(y, p, prob):
    cm = confusion_matrix(y, p, labels=[0,1])
    tn, fp, fn, tp = cm.ravel()
    return {
        "accuracy": float(accuracy_score(y,p)),
        "precision": float(precision_score(y,p,zero_division=0)),
        "recall_sensitivity": float(recall_score(y,p,zero_division=0)),
        "specificity": float(tn/(tn+fp)) if tn+fp else 0.0,
        "f1": float(f1_score(y,p,zero_division=0)),
        "roc_auc": float(roc_auc_score(y,prob)) if len(set(y))==2 else None,
        "confusion_matrix": cm.tolist()
    }

@torch.no_grad()
def evaluate(model, loader, device, criterion=None):
    model.eval(); ys=[]; ps=[]; probs=[]; loss_sum=0; n=0
    for x,y in loader:
        x,y=x.to(device),y.to(device)
        out=model(x)
        if criterion:
            loss_sum += criterion(out,y).item()*len(y); n += len(y)
        prob=torch.softmax(out,1)[:,1]
        pred=out.argmax(1)
        ys += y.cpu().tolist(); ps += pred.cpu().tolist(); probs += prob.cpu().tolist()
    m=metrics(ys,ps,probs)
    if criterion: m["loss"]=loss_sum/max(n,1)
    return m

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--image-dir", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--seed", type=int, default=42)
    args=ap.parse_args()

    seed_everything(args.seed)
    out=Path(args.output); out.mkdir(parents=True,exist_ok=True)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")

    df=load_metadata(args.csv,args.image_dir)
    train,val,test=split_by_patient(df,random_state=args.seed)
    save_splits(train,val,test,out)

    train_ds=DrawingDataset(train,True); val_ds=DrawingDataset(val); test_ds=DrawingDataset(test)
    train_loader=DataLoader(train_ds,args.batch_size,shuffle=True,num_workers=0)
    val_loader=DataLoader(val_ds,args.batch_size,shuffle=False,num_workers=0)
    test_loader=DataLoader(test_ds,args.batch_size,shuffle=False,num_workers=0)

    counts=np.bincount(train.label.values,minlength=2)
    weights=torch.tensor([len(train)/(2*c) if c else 1.0 for c in counts],dtype=torch.float32,device=device)
    model=make_model().to(device)
    criterion=nn.CrossEntropyLoss(weight=weights)
    opt=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=1e-4)
    scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,mode="max",factor=0.5,patience=2)

    best_auc=-1; patience=5; bad=0
    history=[]
    for epoch in range(1,args.epochs+1):
        model.train(); running=0; n=0
        for x,y in train_loader:
            x,y=x.to(device),y.to(device)
            opt.zero_grad()
            loss=criterion(model(x),y)
            loss.backward(); opt.step()
            running += loss.item()*len(y); n += len(y)
        val_m=evaluate(model,val_loader,device,criterion)
        auc=val_m["roc_auc"] if val_m["roc_auc"] is not None else val_m["f1"]
        scheduler.step(auc)
        row={"epoch":epoch,"train_loss":running/max(n,1),**{f"val_{k}":v for k,v in val_m.items() if k!="confusion_matrix"}}
        history.append(row)
        print(row)
        if auc>best_auc:
            best_auc=auc; bad=0
            torch.save({"model_state":model.state_dict(),"class_names":["Control","Parkinson"],
                        "model":"resnet18","image_size":224},out/"best_model.pt")
        else:
            bad+=1
            if bad>=patience: break

    pd.DataFrame(history).to_csv(out/"history.csv",index=False)
    ckpt=torch.load(out/"best_model.pt",map_location=device)
    model.load_state_dict(ckpt["model_state"])
    test_m=evaluate(model,test_loader,device,criterion)
    with open(out/"test_metrics.json","w",encoding="utf-8") as f: json.dump(test_m,f,indent=2)
    print("TEST:",json.dumps(test_m,indent=2))

if __name__=="__main__":
    main()
