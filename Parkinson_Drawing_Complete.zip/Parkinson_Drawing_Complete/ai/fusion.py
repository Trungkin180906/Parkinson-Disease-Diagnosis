def fuse_risk(drawing_score, gait_score, drawing_weight=0.5, gait_weight=0.5):
    total = drawing_weight + gait_weight
    if total <= 0:
        raise ValueError("Tổng trọng số phải > 0")
    score = (drawing_score*drawing_weight + gait_score*gait_weight) / total
    if score <= 30: level="Thấp"
    elif score <= 60: level="Trung bình"
    elif score <= 80: level="Cao"
    else: level="Rất cao"
    return {"overall_risk_score": round(score,2),
            "risk_level":level,
            "recommend_medical_evaluation": score >= 70}
